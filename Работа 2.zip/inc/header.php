<header>
    <img src="images/main/Logo-Photoroom.png" alt="ChessLogo" />
    <nav>
        <ul>
            <li><a href="#">О школе</a></li>
            <li><a href="#">Филиалы</a></li>
            <li><a href="#">Турниры</a></li>
            <li><a href="registration.php">Услуги</a></li>
        </ul>
    </nav>
    <a href="tel:+79876543210" class="telephone"><b>Тел.: +7 987 654 32 10</b></a>
    <img class="tel" src="images/main/Tel.jpg" />
</header>