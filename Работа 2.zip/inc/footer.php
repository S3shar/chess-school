<footer>   
        <div class="footer">
            <img class="foot-logo" src="images/main/Logo-Photoroom.png" />
            <ul>
                <li><img class="logo" src="images/main/inst-logo-Photoroom.png" /></li>
                <li><img class="logo" src="images/main/telegram-logo-Photoroom.jpg" /></li>
            </ul>
        </div>
        <div class="footer-text">
            <div class="address">
                <p class="foot-paragraph">Главный офис:</p>
                <p class="foot-paragraph">Москва, ул. Шахматная, 15 (м. "Парк Культуры")</p>
            </div>
            <div class="contacts">
                <a href="tel:+79876543210"><p class="foot-paragraph">Тел.: +7 987 654 32 10</p></a>
                <a href="mailto:chess@mail.ru"><p class="foot-paragraph">chess@mail.ru</p></a>
            </div>
        </div>
        <div class="filials">
            <a href="#">Филиалы:</a>
            <ul>
                <li>Санкт-Петербург</li>
                <li>Казань</li>
                <li>Екатеринбург</li>
                <li>Саратов</li>
            </ul>
        </div>
    </footer>